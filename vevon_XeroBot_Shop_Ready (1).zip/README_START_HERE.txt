XeroBot Shop Ready — vevon
================================

1) Download & install XeroBot Setup from www.xerobot.in/download.html
2) Double-click CONNECT_SHOP.bat  (connects this PC — no Agent Key hunting)
3) Open XeroBot → select printer → Start Agent

Backup: admin_credentials.txt has Agent Key / owner password if needed.
Support: www.xerobot.in · 90338 94119
