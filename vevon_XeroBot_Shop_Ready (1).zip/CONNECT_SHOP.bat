@echo off
setlocal
cd /d "%~dp0"
echo.
echo  XeroBot — connect this PC to your shop
echo  (no need to find or paste the Agent Key)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONNECT_SHOP.ps1"
set ERR=%ERRORLEVEL%
echo.
if %ERR% NEQ 0 (
  echo  Connect failed. You can still paste the Agent Key from admin_credentials.txt
  echo  into XeroBot → Settings → Connect shop.
  pause
  exit /b %ERR%
)
echo  Done. Open XeroBot → pick printer → Start Agent.
pause
