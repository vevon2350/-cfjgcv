$ErrorActionPreference = "Stop"
$AgentKey = 'xb_HFA_ExrpEzTh8cQtMyz7UWCntSWhRwMf'
$ApiBase = 'https://xerobot-api.vercel.app'
$ShopLabel = 'vevon'
if (-not $AgentKey) { throw "Agent key missing from this pack. Contact support." }
Write-Host "Connecting $ShopLabel to XeroBot..." -ForegroundColor Cyan
$body = @{ agent_key = $AgentKey } | ConvertTo-Json
try {
  $resp = Invoke-RestMethod -Method Post -Uri ($ApiBase.TrimEnd("/") + "/agent/activate") `
    -ContentType "application/json" -Body $body -TimeoutSec 45
} catch {
  throw ("Activate failed: " + $_.Exception.Message)
}
if (-not $resp.success) { throw "Activate rejected by server." }
$cfgDir = Join-Path $env:LOCALAPPDATA "XeroBot"
New-Item -ItemType Directory -Force -Path $cfgDir | Out-Null
$cfgPath = Join-Path $cfgDir "agent_config.json"
$cfg = @{
  architecture_mode = "scalable"
  backend_base = $ApiBase.TrimEnd("/")
  agent_key = $AgentKey
  agent_id = $(if ($resp.agent_id) { [string]$resp.agent_id } else { "pc1" })
  shop_id = [string]$resp.shop_id
  shop_name = [string]$resp.shop_name
  mobile = [string]$resp.mobile
  slug = [string]$resp.slug
  upload_url = [string]$resp.upload_url
  code_seed = $(if ($null -ne $resp.code_seed) { [int]$resp.code_seed } else { 0 })
  max_printers = $(if ($null -ne $resp.max_printers) { [int]$resp.max_printers } else { 1 })
  slim_ui = $true
  auto_switching = $(if ($resp.auto_switching) { $true } else { $false })
  auto_print = $true
  poll_interval = 15
  theme = "light"
  script_url = ""
  password = ""
  printer = ""
}
if ($resp.paper_prices) { $cfg.paper_prices = $resp.paper_prices }
if ($resp.paper_price_tiers) { $cfg.paper_price_tiers = $resp.paper_price_tiers }
if ($null -ne $resp.price_bw) { $cfg.price_bw = $resp.price_bw }
if ($null -ne $resp.price_color) { $cfg.price_color = $resp.price_color }
if ($resp.brand_title) { $cfg.brand_title = [string]$resp.brand_title }
if ($resp.distributor_name) { $cfg.distributor_name = [string]$resp.distributor_name }
$json = $cfg | ConvertTo-Json -Depth 8
[System.IO.File]::WriteAllText($cfgPath, $json + "`n", [System.Text.UTF8Encoding]::new($false))
Write-Host ("Saved: " + $cfgPath) -ForegroundColor Green
Write-Host ("Shop: " + $resp.shop_name + "  ·  " + $resp.upload_url) -ForegroundColor Green
exit 0
